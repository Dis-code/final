from django.apps import AppConfig


class CmsappConfig(AppConfig):
    name = 'cmsapp'
