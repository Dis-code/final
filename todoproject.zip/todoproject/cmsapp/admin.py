from django.contrib import admin
from .models import TaskModel

admin.site.register(TaskModel)
