from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from random import randrange
from todoproject.settings import EMAIL_HOST_USER
from django.core.mail import send_mail

def usignup(request):
	if request.method == "POST":
		un = request.POST.get("un")
		em = request.POST.get("em")
		try:
			usr = User.objects.get(username=un) 
			# print(usr)
			return render(request,'usignup.html',{'msg':' user already registerd'})
		except User.DoesNotExist:
			try:
				usr=User.objects.get(email=em)
				return render(request,'usignup.html',{'msg':'email already registered'})
			except User.DoesNotExist:	
				text = "abcdefghijklmnopqrstuvwxyz1234567890"
				pw = ""
				for i in range(6):
					pw = pw + text[randrange(len(text))]
				print(pw)
				send_mail("Welcome to task site","ur password is " + pw,EMAIL_HOST_USER,[em])
				usr = User.objects.create_user(username=un,password=pw,email=em)
				usr.save()
				return redirect('ulogin')
	else:
		return render(request,'usignup.html')
def ulogin(request):
	if request.method == "POST":
		un = request.POST.get("un")
		pw = request.POST.get("pw")
		usr = authenticate(username=un,password=pw)
		if usr is None:
			return render(request,'ulogin.html',{'msg':'invalid credentials'})
		else:
			login(request,usr)
			return redirect('addtask')
	else:
		return render(request,'ulogin.html')
def ulogout(request):
	logout(request)
	return redirect('ulogin') 

def ureset(request):
	if request.method == "POST":
		un = request.POST.get("un")
		em = request.POST.get("em")
		try:
			usr = User.objects.get(username=un) and User.objects.get(email=em)
			text = "qwertyuioplkjhgfdsazxcvbnm1234567890"
			pw = ""
			for i in range(6):
				pw = pw + text[randrange(len(text))]
			print(pw)
			send_mail("Welcome to task site","ur new password is " + pw,EMAIL_HOST_USER,[em])
			usr.set_password(pw)
			usr.save()
			return redirect('ulogin')
		except User.DoesNotExist:
			return render(request,'ureset.html',{'msg':'invalid username/email'})
	else:
		return render(request,'ureset.html')