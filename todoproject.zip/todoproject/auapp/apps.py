from django.apps import AppConfig


class AuappConfig(AppConfig):
    name = 'auapp'
